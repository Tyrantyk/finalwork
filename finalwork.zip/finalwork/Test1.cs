﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace finalwork
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test()
        {
            int[] order1 = new int[5] { 0, 1, 2, 3, 4 };
            int[] order2 = new int[5] { 2, 3, 4, 5, 6 };

            int[] result2 = new int[10] { 0, 1, 2, 2, 3, 3, 4, 4, 5, 6 };

            tesst sort = new tesst();

            for (int i = 0; i < 10; i++) Assert.AreEqual(sort.Itesst(order1, order2)[i], result2[i]);

        }
    }
}
