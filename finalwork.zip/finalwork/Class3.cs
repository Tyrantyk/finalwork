﻿using System.Text;
using System.Threading.Tasks;

namespace finalwork
{
    class tesst
    {
        public int[] Itesst(int[] ListStr1, int[] ListStr2)
        {

            int num = ListStr1.Length + ListStr2.Length;
            int[] newlist = new int[num];

            for (int i = 0; i < ListStr1.Length; i++) newlist[i] = ListStr1[i];
            for (int i = ListStr1.Length; i < num; i++) newlist[i] = ListStr2[i - ListStr1.Length];

            for (int i = 1; i < newlist.Length; ++i)
            {
                int t = newlist[i];
                int j = i;
                while ((j > 0) && (newlist[j - 1] > t))
                {
                    newlist[j] = newlist[j - 1];
                    --j;
                }
                newlist[j] = t;
            }
            return newlist;




        }
    }
}
